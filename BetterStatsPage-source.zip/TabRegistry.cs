using System;
using System.Collections.Generic;
using UnityEngine;

namespace BetterStatsPage
{
    /// <summary>
    /// Defines a tab that can be displayed in the BetterStatsPage UI.
    /// </summary>
    public class TabDefinition
    {
        /// <summary>
        /// Display name shown on the tab button.
        /// </summary>
        public string Name { get; }

        /// <summary>
        /// Priority for tab ordering. Lower values appear first.
        /// Built-in tabs use 0 (Stats) and 10 (Reputation).
        /// External mods should use values >= 100.
        /// </summary>
        public int Priority { get; }

        /// <summary>
        /// Callback invoked to populate the tab's content.
        /// The Action receives the content Transform and an AddLine helper function.
        /// AddLine signature: void AddLine(string text)
        /// </summary>
        public Action<Transform, Action<string>> ContentBuilder { get; }

        public TabDefinition(string name, int priority, Action<Transform, Action<string>> contentBuilder)
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Priority = priority;
            ContentBuilder = contentBuilder ?? throw new ArgumentNullException(nameof(contentBuilder));
        }
    }

    /// <summary>
    /// Static registry for BetterStatsPage tabs.
    /// External mods can register tabs here, and they will appear in the UI.
    /// </summary>
    public static class TabRegistry
    {
        private static readonly List<TabDefinition> registeredTabs = new List<TabDefinition>();
        private static bool isDirty = true;

        /// <summary>
        /// Event fired when the tab list changes. UI should refresh.
        /// </summary>
        public static event Action OnTabsChanged;

        /// <summary>
        /// Register a new tab with the BetterStatsPage UI.
        /// </summary>
        /// <param name="name">Display name for the tab</param>
        /// <param name="priority">Sort priority (lower = leftmost). Use >= 100 for external mods.</param>
        /// <param name="contentBuilder">Callback to populate content. Receives (contentTransform, addLineHelper).</param>
        public static void RegisterTab(string name, int priority, Action<Transform, Action<string>> contentBuilder)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentException("Tab name cannot be null or empty", nameof(name));

            // Check for duplicate
            if (registeredTabs.Exists(t => t.Name == name))
            {
                Debug.LogWarning($"[TabRegistry] Tab '{name}' is already registered. Ignoring duplicate.");
                return;
            }

            var tab = new TabDefinition(name, priority, contentBuilder);
            registeredTabs.Add(tab);
            isDirty = true;

            Debug.Log($"[TabRegistry] Registered tab: {name} (priority {priority})");
            OnTabsChanged?.Invoke();
        }

        /// <summary>
        /// Unregister a tab by name.
        /// </summary>
        public static void UnregisterTab(string name)
        {
            int removed = registeredTabs.RemoveAll(t => t.Name == name);
            if (removed > 0)
            {
                isDirty = true;
                Debug.Log($"[TabRegistry] Unregistered tab: {name}");
                OnTabsChanged?.Invoke();
            }
        }

        /// <summary>
        /// Get all registered tabs, sorted by priority.
        /// </summary>
        public static IReadOnlyList<TabDefinition> GetTabs()
        {
            if (isDirty)
            {
                registeredTabs.Sort((a, b) => a.Priority.CompareTo(b.Priority));
                isDirty = false;
            }
            return registeredTabs.AsReadOnly();
        }

        /// <summary>
        /// Check if any tabs are registered.
        /// </summary>
        public static bool HasTabs => registeredTabs.Count > 0;

        /// <summary>
        /// Clear all registered tabs. Primarily for testing.
        /// </summary>
        internal static void ClearAll()
        {
            registeredTabs.Clear();
            isDirty = true;
            OnTabsChanged?.Invoke();
        }
    }
}

